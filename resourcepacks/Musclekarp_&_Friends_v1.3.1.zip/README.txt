Datapack by zackdp10 (.druthers on discord)



Origin of each Pokemon:
Musclekarp: https://pokemon-fighters-ex-roblox.fandom.com/wiki/Musclekarp
Neferkiti: https://www.youtube.com/watch?v=0XhOm_9_uPk
Lord Helix: https://helixpedia.fandom.com/wiki/Lord_Helix



How to obtain each Pokemon
--------------------------
Musclekarp: Give a Magikarp a muscle band/Rare spawn on beaches
Sphytty: Common spawn at desert temples and desert wells
Neferkiti: Level up a female Sphytty to 33
Lord Helix: Place a helix fossil and auspicious armor in a fossil machine