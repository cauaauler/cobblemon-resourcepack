Thank you for downloading the Psychie pack! All of the assets in this pack were created by FossilFace for use alongside the Cobblemon mod for Minecraft.

Psychies are monsters from a personal project called Psychies: Bottled Emotions, where the monsters are all based around specific emotions or human experiences. Though technically not Fakemon, I wanted to try modelling and animating them for use in Cobblemon. If you would like to see more designs, feel free to follow my instagram at https://www.instagram.com/fossilface_mh/ .
I may expand on this pack in the future but for now I've selected 6 of my favourite Psychies for you to play with!

These Psychies are:

Derbling, Psychie of Playfulness - A living doll that rolls around looking for fun.

Popora, Psychie of Curiosity - A golden bottle with a shadowy creature inside, waiting to attack those who are curious enough to open it.

Dreadline, Psychie of Stress - An ink pot squid with four quil-tipped limbs to multi-task as much as possible.

Huwatt, Psychie of Confusion - A neuron bird that waddles aimlessly with bursts of electricity shooting from its head.

Nagasius, Psychie of Insecurity - A gorgon attempting to disguise itself as a great serpent in hopes that people will accept it more.

Cinderling, Psychie of Hope - A small candle knight with a flame that refuses to go out.

Petrillop, Psychie of Panic - A flying hare that turns to stone whenever it's frightened.

Slappelin, Psychie of Humour - A comedy duo of a clown and a laughing lollipop. The clown is usually the butt of the joke.

Carquette, Psychie of Intimacy - A clay doll with an exposed heart, seeking out others for warmth and protection.

Heartree, Psychie of Hospitality - A kindly old tree that houses a mysterious creature within its trunk.


The Psychies are all set to spawn in their respective biomes as Rare spawns with a medium weight, however I encourage you to alter the spawn rates to suit your needs if you don't want to spend too long hunting for them.