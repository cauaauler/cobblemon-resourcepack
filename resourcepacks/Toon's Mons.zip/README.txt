This addon was made by ToonSkin. 

This pack can be used on any server that isn't pay to win. The models are also free to use and edit as long as proper credit is given.